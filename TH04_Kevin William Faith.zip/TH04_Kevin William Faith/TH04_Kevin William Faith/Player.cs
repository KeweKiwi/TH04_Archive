﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TH04_Kevin_William_Faith
{
    internal class Player
    {
        private string playerName;
        private string playerNum;
        private string playerPos;

        public Player(string playerName, string playerNum, string playerPos)
        {
            this.PlayerName = playerName;
            this.PlayerNum = playerNum;
            this.PlayerPos = playerPos;
        }

        public string PlayerName { get => playerName; set => playerName = value; }
        public string PlayerNum { get => playerNum; set => playerNum = value; }
        public string PlayerPos { get => playerPos; set => playerPos = value; }
    }
}
